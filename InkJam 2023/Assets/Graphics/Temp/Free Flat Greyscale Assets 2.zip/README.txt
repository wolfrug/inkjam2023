All these assets are under CC0 (aka you don't have to reference them when you make something using them)
However, feel free to attribute these as created by Mark Gosbell if you want to.

https://creativecommons.org/publicdomain/zero/1.0/

Asset Usage tips
Each asset is designed on the same scale so that  70pixels = 1square.
For example if you import these into DungeonScrawl an asset with dimensions 70x70 pixels a 1x1 asset will fit into 1 square.
Each asset has a number x number that is how many squares it is intended to fill.

Find more of my work:
Itch.io
https://itch.io/profile/markgosbell